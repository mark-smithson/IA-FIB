# Instrucciones
- Instalar requierements.txt
        pip install -r requirements.txt
        
Todos los experimentos ejecutan el programa con los parametros necesarios creando así una carpeta de outputs y posteriormente grafica estos resultados en una carpeta llamada plots.
- Experimento 1 pasando como argumento el .jar del programa
        python experiment1.py "Practica 1.jar"
- Experimento 2 pasando como argumento el path de la carpeta outputs del experimento anterior
        python experiment2.py "../Experiment 1/outputs"
- Experimento 3 pasando como argumento el .jar del programa
        python experiment3.py "Practica 1.jar"
- Experimento 4 pasando como argumento el .jar del programa
        python experiment4.py "Practica 1.jar"
- Experimento 5 pasando como argumento el .jar del programa
        python experiment5.py "Practica 1.jar"
- Experimento 6 pasando como argumento el .jar del programa
        python experiment6.py "Practica 1.jar"